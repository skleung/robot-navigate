'''
/* =======================================================================
   (c) 2015, Kre8 Technology, Inc.

   PROPRIETARY and CONFIDENTIAL

   This file contains source code that constitutes proprietary and
   confidential information created by David Zhu

   Kre8 Technology retains the title, ownership and intellectual property rights
   in and to the Software and all subsequent copies regardless of the
   form or media.  Copying or distributing any portion of this file
   without the written permission of Kre8 Technology is prohibited.

   Use of this code is governed by the license agreement,
   confidentiality agreement, and/or other agreement under which it
   was distributed. When conflicts or ambiguities exist between this
   header and the written agreement, the agreement supersedes this file.
   ========================================================================*/
'''

import Tkinter as tk
import time
from HamsterAPI.comm_ble import RobotComm
import math
import numpy as np
import threading
from tk_hamster_GUI import *

UPDATE_INTERVAL = 30

comm = None
gMaxRobotNum = 1; # max number of robots to control
# gRobotList = None
gQuit = False
m = None

#objects in the world
rectF = [0, 50, 40, -50]
rectC = [0, 140, -100, 180]
rectB = [-100, 180, -140, 80]
rectE = [0, -140, -100, -180]
rectD = [-100, -180, -140, -80]
rectA = [-220, -20, -260, 20]

#localizing state is initailized to first localize to the x of F
localize_state = "Fx"

class VirtualWorldGui:
    def __init__(self, vWorld, joystick, m):
        self.vworld = vWorld
        self.joystick = joystick
        self.gRobotList = None

        self.button0 = tk.Button(m,text="Grid")
        self.button0.pack(side='left')
        self.button0.bind('<Button-1>', self.drawGrid)

        self.button1 = tk.Button(m,text="Clear")
        self.button1.pack(side='left')
        self.button1.bind('<Button-1>', self.clearCanvas)

        self.button2 = tk.Button(m,text="Reset")
        self.button2.pack(side='left')
        self.button2.bind('<Button-1>', self.resetvRobot)

        self.button3 = tk.Button(m,text="Map")
        self.button3.pack(side='left')
        self.button3.bind('<Button-1>', self.drawMap)

        self.button4 = tk.Button(m,text="Trace")
        self.button4.pack(side='left')
        self.button4.bind('<Button-1>', self.toggleTrace)

        self.button5 = tk.Button(m,text="Prox Dots")
        self.button5.pack(side='left')
        self.button5.bind('<Button-1>', self.toggleProx)

        self.button6 = tk.Button(m,text="Floor Dots")
        self.button6.pack(side='left')
        self.button6.bind('<Button-1>', self.toggleFloor)

        self.button7 = tk.Button(m,text="Localize")
        self.button7.pack(side='left')
        self.button7.bind('<Button-1>', self.localize)

        self.button8 = tk.Button(m,text="START")
        self.button8.pack(side='left')
        self.button8.bind('<Button-1>', self.start_navigating)

        self.button9 = tk.Button(m,text="Exit")
        self.button9.pack(side='left')
        self.button9.bind('<Button-1>', stopProg)

    # reset to the starting position for 3-2
    def resetvRobot(self, event=None):
        self.vworld.vrobot.x = 230
        self.vworld.vrobot.a = -math.pi/2

    def toggleTrace(self, event=None):
        if self.vworld.trace:
            self.vworld.trace = False
            self.button4["text"] = "Trace"
        else:
            self.vworld.trace = True
            self.button4["text"] = "No Trace"

    def toggleProx(self, event=None):
        if self.vworld.prox_dots:
            self.vworld.prox_dots = False
            self.button5["text"] = "Prox Dots"
        else:
            self.vworld.prox_dots = True
            self.button5["text"] = "No Prox Dots"

    def toggleFloor(self, event=None):
        if self.vworld.floor_dots:
            self.vworld.floor_dots = False
            self.button6["text"] = "Floor Dots"
        else:
            self.vworld.floor_dots = True
            self.button6["text"] = "No Floor Dots"

    def drawMap(self, event=None):
        self.vworld.draw_map()

    def drawGrid(self, event=None):
        x1, y1 = 0, 0
        x2, y2 = self.vworld.canvas_width*2, self.vworld.canvas_height*2
        del_x, del_y = 20, 20
        num_x, num_y = x2 / del_x, y2 / del_y
        # draw center (0,0)
        self.vworld.canvas.create_rectangle(self.vworld.canvas_width-3,self.vworld.canvas_height-3,
                self.vworld.canvas_width+3,self.vworld.canvas_height+3, fill="red")
        # horizontal grid
        for i in range(num_y):
            y = i * del_y
            self.vworld.canvas.create_line(x1, y, x2, y, fill="yellow")
        # verticle grid
        for j in range(num_x):
            x = j * del_x
            self.vworld.canvas.create_line(x, y1, x, y2, fill="yellow")

    def clearCanvas(self, event=None):
        vcanvas = self.vworld.canvas
        vrobot = self.vworld.vrobot
        vcanvas.delete("all")
        poly_points = [0,0,0,0,0,0,0,0]
        vrobot.poly_id = vcanvas.create_polygon(poly_points, fill='blue')
        vrobot.prox_l_id = vcanvas.create_line(0,0,0,0, fill="red")
        vrobot.prox_r_id = vcanvas.create_line(0,0,0,0, fill="red")
        vrobot.floor_l_id = vcanvas.create_oval(0,0,0,0, outline="white", fill="white")
        vrobot.floor_r_id = vcanvas.create_oval(0,0,0,0, outline="white", fill="white")

    def updateCanvas(self, drawQueue):
        self.vworld.canvas.after(UPDATE_INTERVAL, self.updateCanvas, drawQueue)
        while (drawQueue.qsize() > 0):
            drawCommand = drawQueue.get()
            drawCommand()

    def localize(self, localize_state):
        xs = []
        ys = []
        print "proximity left = ", self.vworld.vrobot.dist_l
        print "proximity right = ", self.vworld.vrobot.dist_r
        for _ in range(10):
            xs.append(2)
            ys.append(self.vworld.vrobot.dist_l)
            xs.append(38)
            ys.append(self.vworld.vrobot.dist_r)
        m, b = calculate_least_sqs(xs, ys)
        perp_dist = sum(ys)/float(len(ys)) + 20 # 20 is half of the robot's length
        angle = math.atan(m)
        self.localize_helper(angle, perp_dist, localize_state)

    def localize_helper(self, angle, perp_dist, localize_state):
        print "LOCALIZING WITH ", angle, perp_dist
        print "DIST", math.cos(angle)*perp_dist
        if localize_state == "Fx":
            self.vworld.vrobot.a = angle + 3*math.pi/2
            self.vworld.vrobot.x = rectF[2] + math.cos(angle)*perp_dist
        elif localize_state == "Bx":
            self.vworld.vrobot.a = angle + 3*math.pi/2
            self.vworld.vrobot.x = rectB[0] + math.cos(angle)*perp_dist
        elif localize_state == "Cy":
            self.vworld.vrobot.a = angle
            self.vworld.vrobot.y = rectC[1] - math.cos(angle)*perp_dist
        elif localize_state == "Fx2":
            self.vworld.vrobot.a = angle + math.pi/2
            self.vworld.vrobot.x = rectF[0] - math.cos(angle)*perp_dist
        elif localize_state == "A":
            self.vworld.vrobot.a = angle + 3*math.pi/2
            self.vworld.vrobot.x = rectA[0] + math.cos(angle)*perp_dist

    def start_navigating(self, event=None):
        print "START NAVIGATION PRESSED"
        navigate_vrobot_thread = threading.Thread(target=self.navigate_robot)
        navigate_vrobot_thread.daemon = True
        navigate_vrobot_thread.start()

    # aligns robot to face an obstacle head on
    def align_robot(self):
        vrobot = self.vworld.vrobot
        if (vrobot.dist_r > vrobot.dist_l):
            self.joystick.move_left()
            while(vrobot.dist_r > vrobot.dist_l):
                time.sleep(0.05)
        else:
            self.joystick.move_right()
            while(vrobot.dist_l > vrobot.dist_r):
                time.sleep(0.05)
        self.joystick.stop_move()

    # aligns robot to face the last obstacle
    def align_robot_end(self):
        vrobot = self.vworld.vrobot
        print "ending"
        if (vrobot.dist_r and not vrobot.dist_l):
            print "case 1"
            self.joystick.move_right()
            while(not vrobot.dist_l):
                time.sleep(0.075)
        elif (vrobot.dist_l and not vrobot.dist_r):
            print "case 2"
            self.joystick.move_left()
            while(not vrobot.dist_r):
                time.sleep(0.075)
        else:
            print "case 3"
            self.align_robot()
        self.joystick.stop_move()

    def navigate_robot(self):
        joystick = self.joystick
        vworld = self.vworld
        time.sleep(1) # give time for robot to connect.
        vrobot = vworld.vrobot

        while not joystick.gRobotList:
            print "waiting for robot to connect"
            time.sleep(0.1)

        self.resetvRobot()
        # put a random delay
        time.sleep(1)

        joystick.move_up()
        while (vworld.vrobot.x > 80):
            print vrobot.x, vrobot.a
            time.sleep(0.1)
        joystick.stop_move()
        self.localize("Fx")
        joystick.turn_clockwise(math.pi*2)
        joystick.move_up()
        while (vworld.vrobot.y < 80):
            time.sleep(0.1)
        joystick.turn_counterclockwise(math.pi*3/2)
        joystick.move_up()
        while (vworld.vrobot.x > -55):
            print vrobot.x
            time.sleep(0.1)
        joystick.stop_move()
        self.localize("Bx")
        # joystick.turn_clockwise(0)
        joystick.move_right()
        time.sleep(1.5)
        joystick.stop_move()
        for _ in range(3):
            self.align_robot()
        self.localize("Cy")
        joystick.move_down()
        while (vworld.vrobot.y > 0):
            print "Y", vrobot.y
            time.sleep(0.1)
        joystick.turn_clockwise(math.pi/2)
        for _ in range(3):
            self.align_robot()
        self.localize("Fx2")
        joystick.move_down()
        while(vworld.vrobot.x > -160):
            print "X", vrobot.x
            time.sleep(0.1)
        joystick.turn_clockwise(3*math.pi/2+0.2)
        self.align_robot_end()

def calculate_least_sqs(xvalues, yvalues):
    x = np.array(xvalues)
    y = np.array(yvalues)
    A = np.vstack([x, np.ones(len(x))]).T
    m, b = np.linalg.lstsq(A, y)[0]
    return (m, b)

class Joystick:
    def __init__(self, comm, m, rCanvas):
        self.gMaxRobotNum = 1
        self.gRobotList = comm.robotList
        self.m = m
        self.vrobot = virtual_robot()
        self.vrobot.t = time.time()

        rCanvas.bind_all('<w>', self.move_up)
        rCanvas.bind_all('<s>', self.move_down)
        rCanvas.bind_all('<a>', self.move_left)
        rCanvas.bind_all('<d>', self.move_right)
        rCanvas.bind_all('<x>', self.stop_move)
        rCanvas.pack()

    # joysticking the robot
    def move_up(self, event=None):
        if self.gRobotList:
            robot = self.gRobotList[0]
            self.vrobot.sl = 30
            self.vrobot.sr = 30
            robot.set_wheel(0,self.vrobot.sl)
            robot.set_wheel(1,self.vrobot.sr)
            self.vrobot.t = time.time()

    def move_down(self, event=None):
        if self.gRobotList:
            robot = self.gRobotList[0]
            self.vrobot.sl = -30
            self.vrobot.sr = -30
            robot.set_wheel(0,self.vrobot.sl)
            robot.set_wheel(1,self.vrobot.sr)
            self.vrobot.t = time.time()

    def move_left(self, event=None):
        if self.gRobotList:
            robot = self.gRobotList[0]
            self.vrobot.sl = -15
            self.vrobot.sr = 15
            robot.set_wheel(0,self.vrobot.sl)
            robot.set_wheel(1,self.vrobot.sr)
            self.vrobot.t = time.time()

    def move_right(self, event=None):
        if self.gRobotList:
            robot = self.gRobotList[0]
            self.vrobot.sl = 15
            self.vrobot.sr = -15
            robot.set_wheel(0,self.vrobot.sl)
            robot.set_wheel(1,self.vrobot.sr)
            self.vrobot.t = time.time()

    def stop_move(self, event=None):
        if self.gRobotList:
            robot = self.gRobotList[0]
            self.vrobot.sl = 0
            self.vrobot.sr = 0
            robot.set_wheel(0,self.vrobot.sl)
            robot.set_wheel(1,self.vrobot.sr)
            self.vrobot.t = time.time()

    def turn_clockwise(self, angle):
        if self.gRobotList:
            self.move_right()
            while(self.vrobot.a < angle):
                time.sleep(0.1)
            self.stop_move()

    def turn_counterclockwise(self, angle):
        if self.gRobotList:
            self.move_left()
            while(self.vrobot.a > angle):
                time.sleep(0.1)
            self.stop_move()

    def move_to(self, x, y):
        # adjust x
        print "MOVING TO ", x, y
        if (math.cos(self.vrobot.a) > 0): #facing right
            if (x > self.vrobot.x): # target x is to right of x
                self.move_up()
            else:
                self.move_down()
        else:
            if (x > self.vrobot.x): # target x is to right of x
                self.move_down()
            else:
                print "SETTING WHEELS"
                self.move_up()
        if (x > self.vrobot.x):
            while (self.vrobot.x < x):
                print "MOVING x ", x, y
                time.sleep(0.1)
        else:
            while (self.vrobot.x > x):
                print "MOVING x ", x, y
                time.sleep(0.1)

        # adjust y
        if self.turn_helper(math.sin(self.vrobot.a), math.cos(self.vrobot.a)) == "up":
            if (self.vrobot.y < y):
                self.move_up()
            else:
                self.move_down()
        else:
            if (self.vrobot.y > y):
                self.move_up()
            else:
                self.move_down()
        if (y > self.vrobot.y):
            while (self.vrobot.y < y):
                time.sleep(0.1)
        else:
            while (self.vrobot.y > y):
                time.sleep(0.1)

    def turn_helper(self, sin, cos):
        if (sin > 0 and cos > 0):
            self.turn_counterclockwise(0)
            return "up"
        elif (sin < 0 and cos > 0):
            self.turn_clockwise(math.pi)
            return "down"
        elif (sin < 0 and cos < 0):
            self.turn_counterclockwise(math.pi)
            return "down"
        else:
            self.turn_clockwise(0)
            return "up"

    def update_virtual_robot(self):
        # this is the robot modeling code - below is a very simple and inaccurate
        # model, as example of how to use the GUI toolkit you need to create you
        # own model

        noise_prox = 25 # noisy level for proximity
        noise_floor = 20 #floor ambient color - if floor is darker, set higher noise
        p_factor = 1.2 #proximity conversion - assuming linear
        d_factor = 1.1 #travel distance conversion
        a_factor = 16 # rotation conversion, assuming linear

        while not self.gRobotList:
            print "waiting for robot to connect"
            time.sleep(0.1)

        print "connected to robot"

        while not gQuit:
            if self.gRobotList is not None:
                robot = self.gRobotList[0]

                t = time.time()
                del_t = t - self.vrobot.t
                self.vrobot.t = t # update the tick
                if self.vrobot.sl == self.vrobot.sr:
                    self.vrobot.x = self.vrobot.x + self.vrobot.sl * del_t * math.sin(self.vrobot.a) * d_factor
                    self.vrobot.y = self.vrobot.y + self.vrobot.sl * del_t * math.cos(self.vrobot.a) * d_factor
                if self.vrobot.sl == -self.vrobot.sr:
                    self.vrobot.a = self.vrobot.a + (self.vrobot.sl * del_t)/a_factor
                #update sensors
                prox_l = robot.get_proximity(0)
                prox_r = robot.get_proximity(1)
                if (prox_l > noise_prox):
                    self.vrobot.dist_l = (100 - prox_l)*p_factor
                else:
                    self.vrobot.dist_l = False
                if (prox_r > noise_prox):
                    self.vrobot.dist_r = (100 - prox_r)*p_factor
                else:
                    self.vrobot.dist_r = False

                floor_l = robot.get_floor(0)
                floor_r = robot.get_floor(1)
                if (floor_l < noise_floor):
                    self.vrobot.floor_l = floor_l
                else:
                    self.vrobot.floor_l = False
                if (floor_r < noise_floor):
                    self.vrobot.floor_r = floor_r
                else:
                    self.vrobot.floor_r = False
            time.sleep(0.1)

def stopProg(event=None):
    global gQuit
    global m
    m.quit()
    gQuit = True
    print "Exit"

def draw_virtual_world(virtual_world, joystick):
    time.sleep(1) # give time for robot to connect.
    while not gQuit:
        if joystick.gRobotList is not None:
            virtual_world.draw_robot()
            virtual_world.draw_prox("left")
            virtual_world.draw_prox("right")
            virtual_world.draw_floor("left")
            virtual_world.draw_floor("right")
        time.sleep(0.1)

def main(argv=None):
    global m
    global comm
    comm = RobotComm(gMaxRobotNum)
    comm.start()
    print 'Bluetooth starts'
    m = tk.Tk() #root
    drawQueue = Queue.Queue(0)

    #creating tje virtual appearance of the robot
    canvas_width = 700 # half width
    canvas_height = 380 # half height
    rCanvas = tk.Canvas(m, bg="white", width=canvas_width*2, height=canvas_height*2)

    joystick = Joystick(comm, m, rCanvas)

    # visual elements of the virtual robot
    poly_points = [0,0,0,0,0,0,0,0]
    joystick.vrobot.poly_id = rCanvas.create_polygon(poly_points, fill='blue') #robot
    joystick.vrobot.prox_l_id = rCanvas.create_line(0,0,0,0, fill="red") #prox sensors
    joystick.vrobot.prox_r_id = rCanvas.create_line(0,0,0,0, fill="red")
    joystick.vrobot.floor_l_id = rCanvas.create_oval(0,0,0,0, outline="white", fill="white") #floor sensors
    joystick.vrobot.floor_r_id = rCanvas.create_oval(0,0,0,0, outline="white", fill="white")

    time.sleep(1)

    update_vrobot_thread = threading.Thread(target=joystick.update_virtual_robot)
    update_vrobot_thread.daemon = True
    update_vrobot_thread.start()

    #create the virtual worlds that contains the virtual robot
    vWorld = virtual_world(drawQueue, joystick.vrobot, rCanvas, canvas_width, canvas_height)

    vWorld.add_obstacle(rectA)
    vWorld.add_obstacle(rectB)
    vWorld.add_obstacle(rectC)
    vWorld.add_obstacle(rectD)
    vWorld.add_obstacle(rectE)
    vWorld.add_obstacle(rectF)



    draw_world_thread = threading.Thread(target=draw_virtual_world, args=(vWorld, joystick))
    draw_world_thread.daemon = True
    draw_world_thread.start()

    gui = VirtualWorldGui(vWorld, joystick, m)

    rCanvas.after(200, gui.updateCanvas, drawQueue)
    m.mainloop()


    for robot in joystick.gRobotList:
        robot.reset()
    comm.stop()
    comm.join()


if __name__ == "__main__":
    main()